/* Automatically generated from config.h: internal/compiler config. */

#define HAVE_SYS_TYPES_H 1
#define HAVE_UNISTD_H 1
#define PQXX_HAVE_GCC_VISIBILITY 1
#define PQXX_HAVE_ISINF 1
#define PQXX_HAVE_POLL 1
#define PQXX_HAVE_SLEEP 1
#define PQXX_HAVE_STD_ISINF 1
#define PQXX_HAVE_STD_ISNAN 1
#define PQXX_HAVE_STRERROR_R 1
#define PQXX_HAVE_STRERROR_R_GNU 1
#define PQXX_HAVE_SYS_SELECT_H 1
#define PQXX_SELECT_ACCEPTS_NULL 1
